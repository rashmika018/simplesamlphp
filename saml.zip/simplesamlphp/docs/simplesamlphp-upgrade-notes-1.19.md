# Upgrade notes for SimpleSAMLphp 1.19

The minimum PHP version required is now PHP 7.0.
